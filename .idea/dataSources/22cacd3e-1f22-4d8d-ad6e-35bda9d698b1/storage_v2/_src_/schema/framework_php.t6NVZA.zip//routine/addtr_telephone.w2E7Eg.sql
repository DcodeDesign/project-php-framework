create procedure addTr_telephone()
  BEGIN
    INSERT INTO tr_telephones(id_telephone)
    SELECT id_telephone FROM telephones;

    UPDATE tr_telephones
    SET id_login = ( SELECT id_login FROM utilisateurs WHERE login = 't.gravy@thomas-piron.eu'),
    id_role = ( SELECT id_role FROM roles WHERE niveau = 7);
END;

