create procedure addTr_professions()
  BEGIN
    INSERT INTO tr_professions(id_profession)
    SELECT id_profession FROM professions;

    UPDATE tr_professions
    SET id_login = ( SELECT id_login FROM utilisateurs WHERE login = 't.gravy@thomas-piron.eu'),
    id_role = ( SELECT id_role FROM roles WHERE niveau = 7);
END;

