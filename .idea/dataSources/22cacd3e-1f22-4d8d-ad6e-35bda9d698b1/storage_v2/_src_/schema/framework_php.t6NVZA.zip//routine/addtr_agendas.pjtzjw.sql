create procedure addTr_agendas()
  BEGIN
    INSERT INTO tr_agendas(id_agenda)
    SELECT id_agenda FROM agenda;

    UPDATE tr_agendas
    SET id_login = ( SELECT id_login FROM utilisateurs WHERE login = 't.gravy@thomas-piron.eu'),
    id_role = ( SELECT id_role FROM roles WHERE niveau = 7);
END;

