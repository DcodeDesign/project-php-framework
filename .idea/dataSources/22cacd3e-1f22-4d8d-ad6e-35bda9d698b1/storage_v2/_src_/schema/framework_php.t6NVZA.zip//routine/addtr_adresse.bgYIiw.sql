create procedure addTr_adresse()
  BEGIN
    INSERT INTO tr_adresses(id_adresse)
    SELECT id_adresse FROM adresses;

    UPDATE tr_adresses
    SET id_login = ( SELECT id_login FROM utilisateurs WHERE login = 't.gravy@thomas-piron.eu'),
    id_role = ( SELECT id_role FROM roles WHERE niveau = 7);
END;

