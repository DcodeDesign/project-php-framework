create procedure addTr_contact()
  BEGIN
    INSERT INTO tr_contacts(id_contact)
    SELECT id_contact FROM contacts;

    UPDATE tr_contacts
    SET id_login = ( SELECT id_login FROM utilisateurs WHERE login = 't.gravy@thomas-piron.eu'),
    id_role = ( SELECT id_role FROM roles WHERE niveau = 7);
END;

